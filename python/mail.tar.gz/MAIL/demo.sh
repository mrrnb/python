#!/bin/bash
source /etc/profile
source /root/.bashrc
/usr/bin/python /root/python/MAIL/eMail.py
